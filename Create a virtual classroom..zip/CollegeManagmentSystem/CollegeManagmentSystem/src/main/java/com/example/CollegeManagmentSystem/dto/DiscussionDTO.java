package com.example.CollegeManagmentSystem.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class DiscussionDTO {
    private Long discussionId;
    private String content;
    private Long parentDiscussionId;
    private Set<DiscussionDTO> discussions;
}
