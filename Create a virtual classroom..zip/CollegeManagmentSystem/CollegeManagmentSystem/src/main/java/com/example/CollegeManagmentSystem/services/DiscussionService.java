package com.example.CollegeManagmentSystem.services;

import com.example.CollegeManagmentSystem.dto.DiscussionDTO;
import com.example.CollegeManagmentSystem.entity.Discussion;
import com.example.CollegeManagmentSystem.repository.DiscussionRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class DiscussionService {

    @Autowired
    private DiscussionRepository discussionRepository;

    public DiscussionDTO getDiscussionById(Long discussionId) {
        Optional<Discussion> discussion = discussionRepository.findById(discussionId);
        return discussion.map(this::convertToDTO).orElse(null);
    }

    public List<DiscussionDTO> getAllDiscussions() {
        return discussionRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public DiscussionDTO createDiscussion(DiscussionDTO discussionDTO) {
        Discussion discussion = convertToEntity(discussionDTO);
        discussion = discussionRepository.save(discussion);
        return convertToDTO(discussion);
    }

    public DiscussionDTO updateDiscussion(Long discussionId, DiscussionDTO discussionDTO) {
        if (!discussionRepository.existsById(discussionId)) {
            throw new EntityNotFoundException("Discussion not found with ID: " + discussionId);
        }
        Discussion discussion = convertToEntity(discussionDTO);
        discussion.setDiscussionId(discussionId);
        discussion = discussionRepository.save(discussion);
        return convertToDTO(discussion);
    }

    public void deleteDiscussion(Long discussionId) {
        if (!discussionRepository.existsById(discussionId)) {
            throw new EntityNotFoundException("Discussion not found with ID: " + discussionId);
        }
        discussionRepository.deleteById(discussionId);
    }

    private DiscussionDTO convertToDTO(Discussion discussion) {
        DiscussionDTO dto = new DiscussionDTO();
        dto.setDiscussionId(discussion.getDiscussionId());
        dto.setContent(discussion.getContent());
        dto.setDiscussions(discussion.getDiscussions().stream().map(this::convertToDTO).collect(Collectors.toSet()));
        return dto;
    }

    private Discussion convertToEntity(DiscussionDTO dto) {
        Discussion discussion = new Discussion();
        discussion.setContent(dto.getContent());
        return discussion;
    }

    public DiscussionDTO updatediscussion(Long discussionId, List<DiscussionDTO> discussionDTOS) {
        Optional<Discussion> discussionOpt = discussionRepository.findById(discussionId);
        if (!discussionOpt.isPresent()) {
            throw new EntityNotFoundException("Discussion not found with ID: " + discussionId);
        }
        Discussion discussion = discussionOpt.get();
        Set<Discussion> replies = discussionDTOS.stream()
                .map(this::convertToEntity)
                .collect(Collectors.toSet());
        discussion.setDiscussions(replies);

        discussion = discussionRepository.save(discussion);


        return convertToDTO(discussion);
    }
}
