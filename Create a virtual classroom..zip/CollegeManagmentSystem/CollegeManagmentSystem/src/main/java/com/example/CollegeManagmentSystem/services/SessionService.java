package com.example.CollegeManagmentSystem.services;

import com.example.CollegeManagmentSystem.dto.LectureDTO;
import com.example.CollegeManagmentSystem.dto.SessionDTO;
import com.example.CollegeManagmentSystem.entity.Lecture;
import com.example.CollegeManagmentSystem.entity.Session;
import com.example.CollegeManagmentSystem.repository.SessionRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class SessionService {

    @Autowired
    private SessionRepository sessionRepository;

    public SessionDTO getSessionById(Long sessionId) {
        Optional<Session> session = sessionRepository.findById(sessionId);
        return session.map(this::convertToDTO).orElse(null);
    }

    public List<SessionDTO> getAllSessions() {
        return sessionRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public SessionDTO createSession(SessionDTO sessionDTO) {
        Session session = convertToEntity(sessionDTO);
        session = sessionRepository.save(session);
        return convertToDTO(session);
    }

    public SessionDTO updateSession(Long sessionId, SessionDTO sessionDTO) {
        if (!sessionRepository.existsById(sessionId)) {
            throw new EntityNotFoundException("Session not found with ID: " + sessionId);
        }
        Session session = convertToEntity(sessionDTO);
        session.setSessionId(sessionId);
        session = sessionRepository.save(session);
        return convertToDTO(session);
    }

    public void deleteSession(Long sessionId) {
        if (!sessionRepository.existsById(sessionId)) {
            throw new EntityNotFoundException("Session not found with ID: " + sessionId);
        }
        sessionRepository.deleteById(sessionId);
    }

    public SessionDTO updateLectures(Long sessionId, List<LectureDTO> lectureDTOs) {
        Optional<Session> sessionOpt = sessionRepository.findById(sessionId);
        if (!sessionOpt.isPresent()) {
            throw new EntityNotFoundException("Session not found with ID: " + sessionId);
        }
        Session session = sessionOpt.get();

        Set<Lecture> lectures = lectureDTOs.stream()
                .map(this::convertLectureToEntity)
                .collect(Collectors.toSet());

        session.setLectures(lectures);
        session = sessionRepository.save(session);

        return convertToDTO(session);
    }

    private SessionDTO convertToDTO(Session session) {
        SessionDTO dto = new SessionDTO();
        dto.setSessionId(session.getSessionId());
        dto.setSessionName(session.getSessionName());
        dto.setLectures(session.getLectures().stream().map(this::convertLectureToDTO).collect(Collectors.toSet()));
        return dto;
    }

    private Session convertToEntity(SessionDTO dto) {
        Session session = new Session();
        session.setSessionName(dto.getSessionName());
        return session;
    }

    private LectureDTO convertLectureToDTO(Lecture lecture) {

        LectureDTO dto = new LectureDTO();
        dto.setLectureId(lecture.getLectureId());
        dto.setLectureTitle(lecture.getLectureTitle());

        return dto;
    }

    private Lecture convertLectureToEntity(LectureDTO dto) {
        Lecture lecture = new Lecture();
        lecture.setLectureId(dto.getLectureId());
        lecture.setContent(dto.getContent());

        return lecture;
    }
}
