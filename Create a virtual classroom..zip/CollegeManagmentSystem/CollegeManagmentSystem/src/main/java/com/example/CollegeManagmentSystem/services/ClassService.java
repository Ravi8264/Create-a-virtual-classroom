package com.example.CollegeManagmentSystem.services;

import com.example.CollegeManagmentSystem.dto.ClassDTO;
import com.example.CollegeManagmentSystem.dto.UnitDTO;
import com.example.CollegeManagmentSystem.entity.Class;
import com.example.CollegeManagmentSystem.entity.Unit;
import com.example.CollegeManagmentSystem.entity.User;
import com.example.CollegeManagmentSystem.repository.ClassRepository;
import com.example.CollegeManagmentSystem.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ClassService {

    @Autowired
    private ClassRepository classRepository;

    @Autowired
    private UserRepository userRepository;

    public ClassDTO getClassById(Long classId) {
        Optional<Class> clazz = classRepository.findById(classId);
        return clazz.map(this::convertToDTO).orElse(null);
    }

    public List<ClassDTO> getAllClasses() {
        return classRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public ClassDTO createClass(ClassDTO classDTO) {
        Class clazz = convertToEntity(classDTO);
        clazz = classRepository.save(clazz);
        return convertToDTO(clazz);
    }

    public ClassDTO updateClass(Long classId, ClassDTO classDTO) {
        if (!classRepository.existsById(classId)) {
            throw new EntityNotFoundException("Class not found with ID: " + classId);
        }
        Class clazz = convertToEntity(classDTO);
        clazz.setClassId(classId);
        clazz = classRepository.save(clazz);
        return convertToDTO(clazz);
    }

    public void deleteClass(Long classId) {
        if (!classRepository.existsById(classId)) {
            throw new EntityNotFoundException("Class not found with ID: " + classId);
        }
        classRepository.deleteById(classId);
    }

    public ClassDTO updateInstructor(Long classId, Long instructorId) {
        Class clazz = classRepository.findById(classId)
                .orElseThrow(() -> new EntityNotFoundException("Class not found with ID: " + classId));

        User instructor = userRepository.findById(instructorId)
                .orElseThrow(() -> new EntityNotFoundException("Instructor not found with ID: " + instructorId));

        clazz.setInstructor(instructor);
        clazz = classRepository.save(clazz);
        return convertToDTO(clazz);
    }

    public ClassDTO addStudent(Long classId, Long studentId) {
        Class clazz = classRepository.findById(classId)
                .orElseThrow(() -> new EntityNotFoundException("Class not found with ID: " + classId));

        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new EntityNotFoundException("Student not found with ID: " + studentId));

        clazz.getStudents().add(student);
        clazz = classRepository.save(clazz);
        return convertToDTO(clazz);
    }

    public ClassDTO updateStudents(Long classId, Set<Long> studentIds) {
        Class clazz = classRepository.findById(classId)
                .orElseThrow(() -> new EntityNotFoundException("Class not found with ID: " + classId));

        Set<User> students = studentIds.stream()
                .map(studentId -> userRepository.findById(studentId)
                        .orElseThrow(() -> new EntityNotFoundException("Student not found with ID: " + studentId)))
                .collect(Collectors.toSet());

        clazz.setStudents(students);
        clazz = classRepository.save(clazz);
        return convertToDTO(clazz);
    }

    public ClassDTO addUnit(Long classId, Long unitId) {
        Class clazz = classRepository.findById(classId)
                .orElseThrow(() -> new EntityNotFoundException("Class not found with ID: " + classId));

        Unit unit = new Unit();
        unit.setUnitId(unitId);
        // Optionally, fetch unit from repository if necessary

        clazz.getUnits().add(unit);
        clazz = classRepository.save(clazz);
        return convertToDTO(clazz);
    }

    public ClassDTO updateUnits(Long classId, Set<Long> unitIds) {
        Class clazz = classRepository.findById(classId)
                .orElseThrow(() -> new EntityNotFoundException("Class not found with ID: " + classId));

        Set<Unit> units = unitIds.stream()
                .map(unitId -> {
                    Unit unit = new Unit();
                    unit.setUnitId(unitId);
                    // Optionally, fetch unit from repository if necessary
                    return unit;
                })
                .collect(Collectors.toSet());

        clazz.setUnits(units);
        clazz = classRepository.save(clazz);
        return convertToDTO(clazz);
    }

    private ClassDTO convertToDTO(Class clazz) {
        ClassDTO dto = new ClassDTO();
        dto.setClassId(clazz.getClassId());
        dto.setClassName(clazz.getClassName());
        dto.setDescription(clazz.getDescription());

        if (clazz.getInstructor() != null) {
            dto.setInstructorId(clazz.getInstructor().getUserId());
        }

        if (clazz.getStudents() != null) {
            dto.setStudentIds(clazz.getStudents().stream().map(User::getUserId).collect(Collectors.toSet()));
        }

        if (clazz.getUnits() != null) {
            dto.setUnits(clazz.getUnits().stream().map(this::convertUnitToDTO).collect(Collectors.toSet()));
        }

        return dto;
    }

    private Class convertToEntity(ClassDTO dto) {
        Class clazz = new Class();
        clazz.setClassName(dto.getClassName());
        clazz.setDescription(dto.getDescription());

        if (dto.getInstructorId() != null) {
            User instructor = userRepository.findById(dto.getInstructorId())
                    .orElseThrow(() -> new EntityNotFoundException("Instructor not found with ID: " + dto.getInstructorId()));
            clazz.setInstructor(instructor);
        }

        if (dto.getStudentIds() != null) {
            Set<User> students = dto.getStudentIds().stream()
                    .map(userId -> userRepository.findById(userId)
                            .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId)))
                    .collect(Collectors.toSet());
            clazz.setStudents(students);
        }

        return clazz;
    }

    private UnitDTO convertUnitToDTO(Unit unit) {
        UnitDTO dto = new UnitDTO();
        dto.setUnitId(unit.getUnitId());
        dto.setUnitName(unit.getUnitName());
        return dto;
    }
}
