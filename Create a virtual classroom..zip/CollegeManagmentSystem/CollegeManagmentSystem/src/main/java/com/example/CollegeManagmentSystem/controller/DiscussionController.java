package com.example.CollegeManagmentSystem.controller;

import com.example.CollegeManagmentSystem.dto.DiscussionDTO;

import com.example.CollegeManagmentSystem.services.DiscussionService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/discussions")
public class DiscussionController {

    @Autowired
    private DiscussionService discussionService;

    @GetMapping("/{id}")
    public ResponseEntity<DiscussionDTO> getDiscussionById(@PathVariable("id") Long discussionId) {
        DiscussionDTO discussionDTO = discussionService.getDiscussionById(discussionId);
        if (discussionDTO == null) {
            throw new EntityNotFoundException("Discussion not found with ID: " + discussionId);
        }
        return ResponseEntity.ok(discussionDTO);
    }

    @GetMapping
    public ResponseEntity<List<DiscussionDTO>> getAllDiscussions() {
        List<DiscussionDTO> discussions = discussionService.getAllDiscussions();
        return ResponseEntity.ok(discussions);
    }

    @PostMapping
    public ResponseEntity<DiscussionDTO> createDiscussion(@RequestBody DiscussionDTO discussionDTO) {
        DiscussionDTO createdDiscussion = discussionService.createDiscussion(discussionDTO);
        return ResponseEntity.ok(createdDiscussion);
    }

    @PutMapping("/{id}")
    public ResponseEntity<DiscussionDTO> updateDiscussion(@PathVariable("id") Long discussionId, @RequestBody DiscussionDTO discussionDTO) {
        DiscussionDTO updatedDiscussion = discussionService.updateDiscussion(discussionId, discussionDTO);
        if (updatedDiscussion == null) {
            throw new EntityNotFoundException("Discussion not found with ID: " + discussionId);
        }
        return ResponseEntity.ok(updatedDiscussion);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDiscussion(@PathVariable("id") Long discussionId) {
        discussionService.deleteDiscussion(discussionId);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/discussion")
    public ResponseEntity<DiscussionDTO> updateReplies(@PathVariable("id") Long discussionId, @RequestBody List<DiscussionDTO> discussionDTOS) {
        DiscussionDTO updatedDiscussion = discussionService.updatediscussion(discussionId,discussionDTOS);
        if (updatedDiscussion == null) {
            throw new EntityNotFoundException("Discussion not found with ID: " + discussionId);
        }
        return ResponseEntity.ok(updatedDiscussion);
    }
}
