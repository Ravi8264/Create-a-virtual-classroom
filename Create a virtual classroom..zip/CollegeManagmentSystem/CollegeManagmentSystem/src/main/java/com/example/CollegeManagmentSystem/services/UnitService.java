package com.example.CollegeManagmentSystem.services;

import com.example.CollegeManagmentSystem.dto.SessionDTO;
import com.example.CollegeManagmentSystem.dto.UnitDTO;
import com.example.CollegeManagmentSystem.entity.Session;
import com.example.CollegeManagmentSystem.entity.Unit;
import com.example.CollegeManagmentSystem.repository.UnitRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UnitService {

    @Autowired
    private UnitRepository unitRepository;

    public UnitDTO getUnitById(Long unitId) {
        Optional<Unit> unit = unitRepository.findById(unitId);
        return unit.map(this::convertToDTO).orElse(null);
    }

    public List<UnitDTO> getAllUnits() {
        return unitRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public UnitDTO createUnit(UnitDTO unitDTO) {
        Unit unit = convertToEntity(unitDTO);
        unit = unitRepository.save(unit);
        return convertToDTO(unit);
    }

    public UnitDTO updateUnit(Long unitId, UnitDTO unitDTO) {
        if (!unitRepository.existsById(unitId)) {
            throw new EntityNotFoundException("Unit not found with ID: " + unitId);
        }
        Unit unit = convertToEntity(unitDTO);
        unit.setUnitId(unitId);
        unit = unitRepository.save(unit);
        return convertToDTO(unit);
    }

    public void deleteUnit(Long unitId) {
        if (!unitRepository.existsById(unitId)) {
            throw new EntityNotFoundException("Unit not found with ID: " + unitId);
        }
        unitRepository.deleteById(unitId);
    }

    private UnitDTO convertToDTO(Unit unit) {
        UnitDTO dto = new UnitDTO();
        dto.setUnitId(unit.getUnitId());
        dto.setUnitName(unit.getUnitName());
        dto.setSessions(unit.getSessions().stream().map(this::convertSessionToDTO).collect(Collectors.toSet()));
        return dto;
    }

    private Unit convertToEntity(UnitDTO dto) {
        Unit unit = new Unit();
        unit.setUnitName(dto.getUnitName());
        return unit;
    }

    private SessionDTO convertSessionToDTO(Session session) {
        // Convert Session entity to SessionDTO
        return new SessionDTO();
    }
}
