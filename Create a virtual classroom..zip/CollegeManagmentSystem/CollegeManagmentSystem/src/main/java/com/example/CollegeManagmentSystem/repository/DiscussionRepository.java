package com.example.CollegeManagmentSystem.repository;

import com.example.CollegeManagmentSystem.entity.Discussion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DiscussionRepository extends JpaRepository<Discussion, Long> {
}
