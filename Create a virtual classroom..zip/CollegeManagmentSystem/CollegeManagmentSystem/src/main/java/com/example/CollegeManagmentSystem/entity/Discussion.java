package com.example.CollegeManagmentSystem.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "discussions")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Discussion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long discussionId;

    @Column(nullable = false)
    @Lob // Large Object for storing large text
    private String content;

    @ManyToOne
    @JoinColumn(name = "lecture_id")
    private Lecture lecture;

    @ManyToOne
    @JoinColumn(name = "parent_discussion_id")
    private Discussion parentDiscussion;

    @OneToMany(mappedBy = "parentDiscussion")
    private Set<Discussion> discussions=new HashSet<>();
}
