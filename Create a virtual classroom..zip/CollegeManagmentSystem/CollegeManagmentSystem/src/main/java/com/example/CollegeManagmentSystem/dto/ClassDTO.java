package com.example.CollegeManagmentSystem.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ClassDTO {
    private Long classId;
    private String className;
    private String description;
    private Long instructorId;
    private Set<Long> studentIds;
    private Set<UnitDTO> units;
}
