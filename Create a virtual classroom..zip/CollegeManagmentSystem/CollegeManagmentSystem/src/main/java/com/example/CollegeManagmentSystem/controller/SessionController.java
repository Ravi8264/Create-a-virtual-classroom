package com.example.CollegeManagmentSystem.controller;

import com.example.CollegeManagmentSystem.dto.LectureDTO;
import com.example.CollegeManagmentSystem.dto.SessionDTO;
import com.example.CollegeManagmentSystem.services.SessionService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sessions")
public class SessionController {

    @Autowired
    private SessionService sessionService;

    @GetMapping("/{id}")
    public ResponseEntity<SessionDTO> getSessionById(@PathVariable("id") Long sessionId) {
        SessionDTO sessionDTO = sessionService.getSessionById(sessionId);
        if (sessionDTO == null) {
            throw new EntityNotFoundException("Session not found with ID: " + sessionId);
        }
        return ResponseEntity.ok(sessionDTO);
    }

    @GetMapping
    public ResponseEntity<List<SessionDTO>> getAllSessions() {
        List<SessionDTO> sessions = sessionService.getAllSessions();
        return ResponseEntity.ok(sessions);
    }

    @PostMapping
    public ResponseEntity<SessionDTO> createSession(@RequestBody SessionDTO sessionDTO) {
        SessionDTO createdSession = sessionService.createSession(sessionDTO);
        return ResponseEntity.ok(createdSession);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SessionDTO> updateSession(@PathVariable("id") Long sessionId, @RequestBody SessionDTO sessionDTO) {
        SessionDTO updatedSession = sessionService.updateSession(sessionId, sessionDTO);
        if (updatedSession == null) {
            throw new EntityNotFoundException("Session not found with ID: " + sessionId);
        }
        return ResponseEntity.ok(updatedSession);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSession(@PathVariable("id") Long sessionId) {
        sessionService.deleteSession(sessionId);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/lectures")
    public ResponseEntity<SessionDTO> updateLectures(@PathVariable("id") Long sessionId, @RequestBody List<LectureDTO> lectureDTOs) {
        SessionDTO updatedSession = sessionService.updateLectures(sessionId, lectureDTOs);
        if (updatedSession == null) {
            throw new EntityNotFoundException("Session not found with ID: " + sessionId);
        }
        return ResponseEntity.ok(updatedSession);
    }
}
