package com.example.CollegeManagmentSystem.services;

import com.example.CollegeManagmentSystem.dto.DiscussionDTO;
import com.example.CollegeManagmentSystem.dto.LectureDTO;
import com.example.CollegeManagmentSystem.entity.Discussion;
import com.example.CollegeManagmentSystem.entity.Lecture;
import com.example.CollegeManagmentSystem.repository.LectureRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class LectureService {

    @Autowired
    private LectureRepository lectureRepository;

    public LectureDTO getLectureById(Long lectureId) {
        Optional<Lecture> lecture = lectureRepository.findById(lectureId);
        return lecture.map(this::convertToDTO).orElse(null);
    }

    public List<LectureDTO> getAllLectures() {
        return lectureRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public LectureDTO createLecture(LectureDTO lectureDTO) {
        Lecture lecture = convertToEntity(lectureDTO);
        lecture = lectureRepository.save(lecture);
        return convertToDTO(lecture);
    }

    public LectureDTO updateLecture(Long lectureId, LectureDTO lectureDTO) {
        if (!lectureRepository.existsById(lectureId)) {
            throw new EntityNotFoundException("Lecture not found with ID: " + lectureId);
        }
        Lecture lecture = convertToEntity(lectureDTO);
        lecture.setLectureId(lectureId);
        lecture = lectureRepository.save(lecture);
        return convertToDTO(lecture);
    }

    public void deleteLecture(Long lectureId) {
        if (!lectureRepository.existsById(lectureId)) {
            throw new EntityNotFoundException("Lecture not found with ID: " + lectureId);
        }
        lectureRepository.deleteById(lectureId);
    }

    public LectureDTO updateLectureDiscussions(Long lectureId, List<DiscussionDTO> discussionsDTO) {
        Optional<Lecture> optionalLecture = lectureRepository.findById(lectureId);
        if (!optionalLecture.isPresent()) {
            throw new EntityNotFoundException("Lecture not found with ID: " + lectureId);
        }

        Lecture lecture = optionalLecture.get();
        Set<Discussion> discussions = discussionsDTO.stream()
                .map(this::convertToDiscussionEntity)
                .collect(Collectors.toSet());

        lecture.setDiscussions(discussions);
        lecture = lectureRepository.save(lecture);
        return convertToDTO(lecture);
    }

    private LectureDTO convertToDTO(Lecture lecture) {
        LectureDTO dto = new LectureDTO();
        dto.setLectureId(lecture.getLectureId());
        dto.setLectureTitle(lecture.getLectureTitle());
        dto.setContent(lecture.getContent());
        dto.setDiscussions(lecture.getDiscussions().stream().map(this::convertDiscussionToDTO).collect(Collectors.toSet()));
        return dto;
    }

    private Lecture convertToEntity(LectureDTO dto) {
        Lecture lecture = new Lecture();
        lecture.setLectureTitle(dto.getLectureTitle());
        lecture.setContent(dto.getContent());
        return lecture;
    }

    private DiscussionDTO convertDiscussionToDTO(Discussion discussion) {
        DiscussionDTO dto = new DiscussionDTO();
        // Set properties of dto from discussion
        return dto;
    }

    private Discussion convertToDiscussionEntity(DiscussionDTO dto) {
        Discussion discussion = new Discussion();
        // Set properties of discussion from dto
        return discussion;
    }
}
