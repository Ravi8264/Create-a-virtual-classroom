package com.example.CollegeManagmentSystem.controller;

import com.example.CollegeManagmentSystem.dto.LectureDTO;

import com.example.CollegeManagmentSystem.services.LectureService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.CollegeManagmentSystem.dto.DiscussionDTO;

import java.util.List;

@RestController
@RequestMapping("/api/lectures")
public class LectureController {

    @Autowired
    private LectureService lectureService;

    @GetMapping("/{id}")
    public ResponseEntity<LectureDTO> getLectureById(@PathVariable("id") Long lectureId) {
        LectureDTO lectureDTO = lectureService.getLectureById(lectureId);
        if (lectureDTO == null) {
            throw new EntityNotFoundException("Lecture not found with ID: " + lectureId);
        }
        return ResponseEntity.ok(lectureDTO);
    }

    @GetMapping
    public ResponseEntity<List<LectureDTO>> getAllLectures() {
        List<LectureDTO> lectures = lectureService.getAllLectures();
        return ResponseEntity.ok(lectures);
    }

    @PostMapping
    public ResponseEntity<LectureDTO> createLecture(@RequestBody LectureDTO lectureDTO) {
        LectureDTO createdLecture = lectureService.createLecture(lectureDTO);
        return ResponseEntity.ok(createdLecture);
    }

    @PutMapping("/{id}")
    public ResponseEntity<LectureDTO> updateLecture(@PathVariable("id") Long lectureId, @RequestBody LectureDTO lectureDTO) {
        LectureDTO updatedLecture = lectureService.updateLecture(lectureId, lectureDTO);
        if (updatedLecture == null) {
            throw new EntityNotFoundException("Lecture not found with ID: " + lectureId);
        }
        return ResponseEntity.ok(updatedLecture);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLecture(@PathVariable("id") Long lectureId) {
        lectureService.deleteLecture(lectureId);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/discussions")
    public ResponseEntity<LectureDTO> updateLectureDiscussions(@PathVariable("id") Long lectureId, @RequestBody List<DiscussionDTO> discussionsDTO) {
        LectureDTO updatedLecture = lectureService.updateLectureDiscussions(lectureId, discussionsDTO);
        if (updatedLecture == null) {
            throw new EntityNotFoundException("Lecture not found with ID: " + lectureId);
        }
        return ResponseEntity.ok(updatedLecture);
    }
}
