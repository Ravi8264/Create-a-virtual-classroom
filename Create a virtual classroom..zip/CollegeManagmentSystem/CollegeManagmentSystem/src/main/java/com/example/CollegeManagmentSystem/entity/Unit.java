package com.example.CollegeManagmentSystem.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "units")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Unit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long unitId;

    private String unitName;

    @ManyToOne
    @JoinColumn(name = "class_id") // Ensure this matches the field in Class
    private Class classRoom; // Assuming "Class" is another entity

    @OneToMany(mappedBy = "unit")
    private Set<Session> sessions = new HashSet<>(); // Initialize to an empty set
}
