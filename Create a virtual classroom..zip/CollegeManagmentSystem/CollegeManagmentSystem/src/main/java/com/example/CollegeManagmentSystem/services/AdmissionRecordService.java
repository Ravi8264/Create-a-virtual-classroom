//package com.example.CollegeManagmentSystem.services;
//import com.example.CollegeManagmentSystem.repository.AdmissionRecordRepository;
//import org.springframework.stereotype.Service;
//import java.util.List;
//import java.util.Optional;
//
//
//@Service
//public class AdmissionRecordService {
//    private final AdmissionRecordRepository admissionRecordRepository;
//    public AdmissionRecordService(AdmissionRecordRepository admissionRecordRepository) {
//        this.admissionRecordRepository = admissionRecordRepository;
//    }
//    public List<AdmissionRecord> findAll() {
//        return admissionRecordRepository.findAll();
//    }
//    public Optional<AdmissionRecord> findById(Long id) {
//        return admissionRecordRepository.findById(id);
//    }
//    public AdmissionRecord save(AdmissionRecord admissionRecord) {
//        return admissionRecordRepository.save(admissionRecord);
//    }
//    public void deleteById(Long id) {
//        admissionRecordRepository.deleteById(id);
//    }
//}
