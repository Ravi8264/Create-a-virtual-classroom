package com.example.CollegeManagmentSystem.controller;

import com.example.CollegeManagmentSystem.dto.ClassDTO;
import com.example.CollegeManagmentSystem.services.ClassService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/classes")
public class ClassController {

    @Autowired
    private ClassService classService;

    @GetMapping("/{id}")
    public ResponseEntity<ClassDTO> getClassById(@PathVariable("id") Long classId) {
        ClassDTO classDTO = classService.getClassById(classId);
        if (classDTO == null) {
            throw new EntityNotFoundException("Class not found with ID: " + classId);
        }
        return ResponseEntity.ok(classDTO);
    }

    @GetMapping
    public ResponseEntity<List<ClassDTO>> getAllClasses() {
        List<ClassDTO> classes = classService.getAllClasses();
        return ResponseEntity.ok(classes);
    }

    @PostMapping
    public ResponseEntity<ClassDTO> createClass(@RequestBody ClassDTO classDTO) {
        ClassDTO createdClass = classService.createClass(classDTO);
        return ResponseEntity.ok(createdClass);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ClassDTO> updateClass(@PathVariable("id") Long classId, @RequestBody ClassDTO classDTO) {
        ClassDTO updatedClass = classService.updateClass(classId, classDTO);
        if (updatedClass == null) {
            throw new EntityNotFoundException("Class not found with ID: " + classId);
        }
        return ResponseEntity.ok(updatedClass);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteClass(@PathVariable("id") Long classId) {
        classService.deleteClass(classId);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/instructor")
    public ResponseEntity<ClassDTO> updateInstructor(@PathVariable("id") Long classId, @RequestBody Long instructorId) {
        ClassDTO updatedClass = classService.updateInstructor(classId, instructorId);
        return ResponseEntity.ok(updatedClass);
    }

    @PutMapping("/{id}/students")
    public ResponseEntity<ClassDTO> updateStudents(@PathVariable("id") Long classId, @RequestBody Set<Long> studentIds) {
        ClassDTO updatedClass = classService.updateStudents(classId, studentIds);
        return ResponseEntity.ok(updatedClass);
    }

    @PutMapping("/{id}/units")
    public ResponseEntity<ClassDTO> updateUnits(@PathVariable("id") Long classId, @RequestBody Set<Long> unitIds) {
        ClassDTO updatedClass = classService.updateUnits(classId, unitIds);
        return ResponseEntity.ok(updatedClass);
    }
}
