package com.example.CollegeManagmentSystem.controller;

import com.example.CollegeManagmentSystem.dto.UnitDTO;


import com.example.CollegeManagmentSystem.services.UnitService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/units")
public class UnitController {

    @Autowired
    private UnitService unitService;

    @GetMapping("/{id}")
    public ResponseEntity<UnitDTO> getUnitById(@PathVariable("id") Long unitId) {
        UnitDTO unitDTO = unitService.getUnitById(unitId);
        if (unitDTO == null) {
            throw new EntityNotFoundException("Unit not found with ID: " + unitId);
        }
        return ResponseEntity.ok(unitDTO);
    }

    @GetMapping
    public ResponseEntity<List<UnitDTO>> getAllUnits() {
        List<UnitDTO> units = unitService.getAllUnits();
        return ResponseEntity.ok(units);
    }

    @PostMapping
    public ResponseEntity<UnitDTO> createUnit(@RequestBody UnitDTO unitDTO) {
        UnitDTO createdUnit = unitService.createUnit(unitDTO);
        return ResponseEntity.ok(createdUnit);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UnitDTO> updateUnit(@PathVariable("id") Long unitId, @RequestBody UnitDTO unitDTO) {
        UnitDTO updatedUnit = unitService.updateUnit(unitId, unitDTO);
        if (updatedUnit == null) {
            throw new EntityNotFoundException("Unit not found with ID: " + unitId);
        }
        return ResponseEntity.ok(updatedUnit);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUnit(@PathVariable("id") Long unitId) {
        unitService.deleteUnit(unitId);
        return ResponseEntity.noContent().build();
    }
}
