package com.example.CollegeManagmentSystem.dto;

import com.example.CollegeManagmentSystem.dto.DiscussionDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class LectureDTO {
    private Long lectureId;
    private String lectureTitle;
    private String content;
    private Set<DiscussionDTO> discussions;
}
