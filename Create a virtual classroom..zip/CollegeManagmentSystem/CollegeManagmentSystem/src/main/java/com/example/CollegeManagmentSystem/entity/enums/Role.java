package com.example.CollegeManagmentSystem.entity.enums;

public enum Role {
    ROLE_STUDENT,
    ROLE_INSTRUCTOR
}
