package com.example.CollegeManagmentSystem.dto;

import com.example.CollegeManagmentSystem.dto.SessionDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UnitDTO {
    private Long unitId;
    private String unitName;
    private Set<SessionDTO> sessions;
}
