package com.example.CollegeManagmentSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeManagmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
